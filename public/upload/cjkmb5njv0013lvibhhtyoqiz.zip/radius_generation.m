%�¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�
% Generate the list of symbol vectors via PRT-LSD
%
%   Input parameters
% s_ml				: ML-solution obtained from SD
% R_ml				: Cost function of the ML-solutino
% H 				: Channel matrix
% d     			: Heuristically defined constant for computing rho
% dof   			: Degree of freedom
% Rho   			: Information of rho from previous transmissions
%
%	Output parameters
% ini_r     		: Initial radius for proposed LSD (PRT-LSD)
%
% Written by Jaeseok Lee
% Information System Lab., Korea Univ.
%�¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�

function [ini_r] = radius_generation(s_ml, R_ml, H, d, dof, Rho)

%% compute the necessary variables for initial radius
randnum = 0;
while randnum == 0
    randnum = round((n_cand-1)*rand(1,1));
end

cnt = 1;
terminate = 0;
while cnt <= randnum

    indx = [ 0 0 ];
    while indx(1) == indx(2)
        indx = ceil(dof*rand(1,2));
    end
    temp = s_ml(indx(2));
    A(:,cnt) = s_ml;
    A(indx(2),cnt) = s_ml(indx(1));
    A(indx(1),cnt) = temp;
    cnt = cnt + 1;

end

for q = 1:size(A,2)
    dis(:,q) = (H*s_ml-H*A(:,q));
    lambda(q) = sum(dis(:,q).^2);
    c(q) = (dof+2*lambda(q))/(dof+lambda(q));
    f(q) = ((dof+lambda(q))^2)/(dof+2*lambda(q));
    C(q) = (c(q)/(2^(f(q)/2)));
end

%% compute the initial radius

% compute rho
rho = mean(C)*exp((R_ml)/2);

% if rho exceeds 1, then use heuristically defined rho or adopt the
% information from previous transmissions
if rho >= 1
    if length(Rho) == 0
        % current transmission is the first transmission
        rho(SNR_indx,a) = 1-d;
    else
        % rho information from previous transmissions
        rho(SNR_indx,a) = mean(Rho);
    end
end

% obtain the initial radius
ini_r = R_ml - 2*log(rho);