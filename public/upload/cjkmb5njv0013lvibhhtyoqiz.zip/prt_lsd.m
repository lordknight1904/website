%�¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�
% Generate the list of symbol vectors via PRT-LSD
% - All the variables are real-valued (converted from complex-valued system)
%
%   Input parameters
% QY				: modified observation (Q'*y)
% R_H				: Triangular matric R when QR-decomposition is employed to channel matrix H
% Sz_M				: Size of the original channel matrix
% ini_r 			: Initial radius
% sym_r 			: Real-valued symbol constellation (ex: if 16-QAM, sym_r = [-3 -1 1 3]
% list_num 			: List size
% s_ml  			: ML-solution obtained in the first stage (SD)
% pe     			: Pruning probability
%
%	Output parameters
% x_list     		: List of symbol vectors
% R_list        	: List of cost functions of the symbol vectors in the list
% n_node    		: Number of visited nodes (complexity)
%
% Written by Jaeseok Lee
% Information System Lab., Korea Univ.
%�¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�

function [x_list, R_list, n_node] = prt_lsd(QY, R_H, Sz_M, ini_r, sym_r, list_num, s_ml, pe)


%% Initialization of the variables

% number of branches of each node
s_sym = length(sym_r);

% list of the symbol vectors and the corresponding cost functions
x_list = zeros(Sz_M*2,list_num);
R_list = zeros(1,list_num);

% index of the elements in the list
cnt_sol = 1;

termination = 0;
n_node = 0;
layer = Sz_M*2;
pathmetric = zeros(Sz_M*2,1);

% search radius
R = ini_r;
Ri = R;
R_list(cnt_sol) = R;

for cnt_l = 1:(Sz_M*2)
    l_info(:,:,cnt_l) = [zeros(1,s_sym); sym_r];
end

l_path = zeros(Sz_M*2,1);

min_sym = zeros(Sz_M*2,1);
present_sym = zeros(Sz_M*2,1);


%% LSD with Pruning
while ~termination

    if l_path(layer) == (s_sym + 1)
        % all the branches of current node have been visited

        if layer == Sz_M*2

            % if all paths are visited, terminate LSD
            termination = 1;

        else

            % move onto next node
            l_path(layer) = 0;
            pathmetric(layer) = 0;
            present_sym(layer) = 0;

            layer = layer + 1;
        end

    else

        if l_path(layer) == 0 % if path is not calculated..
            l_info(:,:,layer) = distcal(QY, R_H, present_sym, l_info(:,:,layer), layer); % Need Modification
            l_info(:,:,layer) = order4(l_info(:,:,layer));
            l_path(layer) = l_path(layer) + 1;
        end

        pathmetric(layer) = l_info(1, l_path(layer), layer);
        n_node = n_node + 1;

        p_sym = present_sym;
        p_sym(layer) = l_info(2, l_path(layer), layer);

        % ---------- compute beta for probabilistic tree pruning ----------
        clear E;
        for q = layer:2*Sz_M
            E(q) = (R_H(q,q:end)*(s_ml(q:end) - p_sym(q:end)));
        end
        mu = sum(E(layer:2*Sz_M).^2);
        dof = layer-1;

        c = (dof + 2*mu)/(dof + mu);
        f = ((dof+mu)^2)/(dof+2*mu);
        if layer == 1
            beta = 0;
        else
            beta = chi2inv(pe / c, f);
        end
        % -----------------------------------------------------------------

        if sum(pathmetric) <= R - beta
            present_sym(layer) = l_info(2, l_path(layer),layer);

            if layer == 1

                % Update R
                R = sum(pathmetric);
                [x_list, R_list] = lsd_sym(x_list, R_list, present_sym, R, cnt_sol);

                % Update the list
                if cnt_sol < list_num
                    cnt_sol = cnt_sol + 1;
                    R = Ri;
                else
                    R = R_list(cnt_sol);
                end

                l_path(layer) = l_path(layer) + 1;

            else
                l_path(layer) = l_path(layer) + 1;
                layer = layer - 1;
            end

        else

            if layer == Sz_M*2
                termination = 1;

            else
                pathmetric(layer) = 0;
                l_path(layer) = 0;
                layer = layer + 1;
            end
        end
    end

end % while

function [x_list_r, R_list_r] = lsd_sym(x_list, R_list, present_sym, R, cnt_sol)
%% List generation
[temp, sz_l] = size(R_list);

loc_p = 1;
for cnt_1 = 1:cnt_sol
    if R > R_list(cnt_1)
        loc_p = loc_p + 1;
    end
end

if loc_p > 1
    x_list_r(:,1:(loc_p-1)) = x_list(:,1:(loc_p-1));
    R_list_r(:,1:(loc_p-1)) = R_list(:,1:(loc_p-1));
end
x_list_r(:,loc_p) = present_sym;
R_list_r(:,loc_p) = R;
x_list_r(:,(loc_p+1):(sz_l)) = x_list(:,loc_p:(sz_l-1));
R_list_r(:,(loc_p+1):(sz_l)) = R_list(:,loc_p:(sz_l-1));