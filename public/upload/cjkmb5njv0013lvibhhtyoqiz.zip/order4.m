function [myout] = order4(myin)

[temp,s_sym] = size(myin);

for cnt1 = 1:(s_sym-1)
    for cnt2 = (cnt1+1):s_sym 
        if myin(1,cnt1) > myin(1,cnt2)
            temp = myin(1,cnt1);
            myin(1,cnt1) = myin(1,cnt2);
            myin(1,cnt2) = temp;
        
            temp = myin(2,cnt1);
            myin(2,cnt1) = myin(2,cnt2);
            myin(2,cnt2) = temp;
        end
    end
end

myout = myin;