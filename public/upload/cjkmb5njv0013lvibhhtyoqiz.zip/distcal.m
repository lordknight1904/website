function [myin] = distcal(QY,R_H,present_sym,myin,layer)

[temp, s_sym] = size(myin);

% General version for NxN case
for cnt_sc = 1:s_sym
    
    temp = QY(layer) - R_H(layer,layer)*myin(2,cnt_sc);
    
    if layer < size(QY,1)
        for cnt_y = (layer+1):size(QY,1)
            temp = temp - R_H(layer,cnt_y)*present_sym(cnt_y);
        end
    end

    myin(1,cnt_sc) = (norm(temp))^2;
end
        
% Old Version for 5x5 case    

%for cnt_sc = 1:4;
%     if layer == 5
%         myin(1,cnt_sc) = (norm( QY(5) - R_H(5,5)*myin(2,cnt_sc) ))^2;
%     elseif layer == 4
%         myin(1,cnt_sc) = (norm( QY(4) - R_H(4,4)*myin(2,cnt_sc) - R_H(4,5)*present_sym(5) ))^2;
%     elseif layer == 3
%         myin(1,cnt_sc) = (norm( QY(3) - R_H(3,3)*myin(2,cnt_sc) - R_H(3,4)*present_sym(4) - R_H(3,5)*present_sym(5) ))^2;
%     elseif layer == 2
%         myin(1,cnt_sc) = (norm( QY(2) - R_H(2,2)*myin(2,cnt_sc) - R_H(2,3)*present_sym(3) - R_H(2,4)*present_sym(4) - R_H(2,5)*present_sym(5) ))^2;
%     elseif layer == 1
%         myin(1,cnt_sc) = (norm( QY(1) - R_H(1,1)*myin(2,cnt_sc) - R_H(1,2)*present_sym(2) - R_H(1,3)*present_sym(3) - R_H(1,4)*present_sym(4) - R_H(1,5)*present_sym(5) ))^2;
%     end
%end