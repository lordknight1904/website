%�¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�
% Test gOMP algorithm
%
% Written by Suhyuk (Seokbeop) Kwon
% Information System Lab., Korea Univ.
% http://isl.korea.ac.kr
%�¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�


% Measurements size
m		= 50;
% Signal size
N		= 100;
% Sparsity level
K		= 20;


% Generate sensing matrix
Phi = randn(m,N)/sqrt(m);

% Generate sparse vector
[x x_pos]	= islsp_GenSparseVec(N, K);

y	= Phi*x;

% Using default parameters
[x1	itr1]	= islsp_EstgOMP(y, Phi, K);

% Find the sparse vector via selecting 4 indices
[x2	itr2]	= islsp_EstgOMP(y, Phi, K, 4);

% Find the sparse vector via selecting 4 indices until the residual becomes 1e-12
[x3	itr3]	= islsp_EstgOMP(y, Phi, K, 4, 1e-12);


disp('Mean square error');
[mse(x-x1) mse(x-x2) mse(x-x3)]

disp('Iteration number');
[itr1 itr2 itr3]

