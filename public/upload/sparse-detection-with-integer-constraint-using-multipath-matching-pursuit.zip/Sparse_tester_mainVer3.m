%-----------------------------------------
% sparse_testerCV.m
%
% This work has been published to COMM-L 2014
% Sparse Detection with Integer Constraint Using Multipath Matching Pursuit
%-----------------------------------------
% Test various sparse estimation techniques (including CV)
%
%-----------------------------------------
clear all;
close all;

fprintf('\n ======================================================================== \n');
fprintf('\n \n');
fprintf('\n Test sMMP Algorithm');
fprintf('\n There will be many warning sign from matlab window but do not be surprised!\n');
fprintf('\n \n');
fprintf('\n ======================================================================== \n');


if 1
% 16QAM
	sym_int		= [1+j 1-j -1+j -1-j 1+3j 1-3j -1+3j -1-3j 3+j 3-j -3+j -3-j 3+3j 3-3j -3+3j -3-3j];
	sym			= sym_int/sqrt(10);
	sym_scale	= sqrt(10);
	sym			= sym.';
	sym_zero	= [sym ; 0];
	sym_r		= [-3 -1 1 3]/sqrt(10);
	sym_r_zero	= [-3 -1 0 1 3]/sqrt(10);
	
	m		= 12;
	m1		= 8; % cv purpose
	n		= 24;
    K       = 3;		
	npow	= 1;		
	snr_dB_vec = [19 22 25 28 31 34 37 40];
	TitleTxt = sprintf('\''MIMO=[%d,%d] with 16-QAM transmission K=%d',m,n,K);
else
% QPSK
	sym_int		= [1+j 1-j -1+j -1-j];
	sym			= sym_int/sqrt(2);
	sym_scale	= sqrt(2);
	sym			= sym.';
	sym_zero	= [sym ; 0];
	sym_r		= [-1 1]/sqrt(2);
	sym_r_zero	= [-1 0 1]/sqrt(2);
	
	m		= 12;
	m1		= 8; % cv purpose
	n		= 24;
	K		= 4;
	npow	= 1;
	snr_dB_vec = [23 25 27 29 31 33 35];
	TitleTxt = sprintf('\''MIMO=[%d,%d] with QPSK transmission (K=%d)',m,n,K);
end


Sim_Param.sym_int	= sym_int;
Sim_Param.sym_r		= sym_r;
Sim_Param.sym_scale	= sym_scale;
%Sim_Param.K = K;
Sim_Param.npow		= npow;
Sim_Param.m			= m;
Sim_Param.n			= n;


Alg_ParamOMP.K_cv	= 11;
%Alg_ParamMMP.MaxIter = min(1*K, m); % K
Alg_ParamMMP.child_len	= 10;
Alg_ParamMMP.K_cv		= round(m/2)+3;
Alg_ParamMMP.cand_len	= 32;
Alg_ParamMMP.reg_factor	= npow;
Alg_ParamMMP.delta		= 2;


N_cv	= 24; % Number of CV test for sparsity estimation
N_sim	= 128; % Number of channel realizations
%%==========================================================================================
for tst = 1:length(snr_dB_vec)
	
	snr_dB	= snr_dB_vec(tst);
	snr_dB_vec(tst) = snr_dB;
	
	N_sim	= N_sim*2;	
	N_sim   = min(N_sim, 10000);

    
	% ------------ clock ------------
	working_clock = clock;
	if working_clock(4) >= 12
		fprintf('\n Run (K=%d) begins at %d:%d pm\n', K, working_clock(4), working_clock(5));
	else
		fprintf('\n Run (K=%d) begins at %d:%d am\n', K, working_clock(4), working_clock(5));
	end
	
	N_alg	= 7;
	ncnt	= 0;
	err		= zeros(1, N_alg);
	for v = 1:(N_sim + N_cv)
	
	% --------------------------------------------------
	% Transmission and channel
	% --------------------------------------------------
		s_int	= sym_int(ceil(rand(n,1)*length(sym))).';
		s		= s_int/sym_scale;
		
		if 1 %SPARSE_ON
			indx = randperm(n);
			nonzero_indx = indx(1:K); % Not ordered
			Sim_Param.nonzero_indx = nonzero_indx;
			s(indx(K+1:end)) = 0;
		end
		
		noise = (randn(m,1) + j*randn(m,1))/sqrt(2);
		
		H = (randn(m,n) + j*randn(m,n))/(n*sqrt(2));
		SNR = sqrt(10.^(snr_dB/10));
		H = SNR*H;
		
		y = H * s + noise;
		
		H1 = H(1:m1, :); % cv purpose
		H2 = H(m1+1:end, :);  % cv purpose
		y1 = y(1:m1); % cv purpose
		y2 = y(m1+1:end); % cv purpose
		

		% --------------------------------------------------
		%
		%
		% CV algorithms for sparsity estimation
		%
		%
		% --------------------------------------------------
		if v <= N_cv
		
			% ----- Initialize  -----
			if v == 1	
				K_est_sum= zeros(1,6);
            end			
			
			alg		= 0;
			sh_tmp	=[];	
			
			%----- OMP + CV
			alg = alg + 1;
			s_est = fOMP_CV(y1, y2, H1, H2, Sim_Param, Alg_ParamOMP);
			sh_tmp = [sh_tmp length(find(s_est ~= 0))];
			K_est_sum(alg) = K_est_sum(alg) + length(find(s_est ~= 0));			
			
			%----- OMP + CV
			alg = alg + 1;
			s_est = fOMP_CV_slice(y1, y2, H1, H2, Sim_Param, Alg_ParamOMP);
			sh_tmp = [sh_tmp length(find(s_est ~= 0))];
			K_est_sum(alg) = K_est_sum(alg) + length(find(s_est ~= 0));
			
			%----- MMP + <CV> -----
			alg = alg + 1;
			[s_est epsilon] = fMMP_CV(y1, y2, H1, H2, Sim_Param, Alg_ParamMMP);
			sh_tmp = [sh_tmp length(find(s_est ~= 0))];
			K_est_sum(alg) = K_est_sum(alg) + length(find(s_est ~= 0));
			
			%----- MMP-slice + <CV> -----
			alg = alg + 1;
			[s_est epsilon] = fMMP_CV_slice(y1, y2, H1, H2, Sim_Param, Alg_ParamMMP);
			sh_tmp = [sh_tmp length(find(s_est ~= 0))];
			K_est_sum(alg) = K_est_sum(alg) + length(find(s_est ~= 0));			
			
			if v == N_cv
                for u = 1:alg
                    K_est(u) = round(K_est_sum(u)/N_cv);
                end
				test_Kest_print = [K K_est]
			end
		
		
		% --------------------------------------------------		
		%
		% Normal operation after the sparsity estimation
		%	
		% --------------------------------------------------
		else % v > N_cv

			alg = 0;
			sym_all = [];
			
			% ----- Oracle MMSE (Reference) -----
			alg = alg + 1;
			LegendTxt{alg} = 'Oracle MMSE';
			npow = 1;
			s_est = fOracleMMSE(y, H, Sim_Param);
			sym_all = [sym_all s_est(Sim_Param.nonzero_indx)];
			
			% ----- Conventional MMSE Algorithm -----
			alg = alg + 1;
			LegendTxt{alg} = 'MMSE';
			npow = 1;
			s_est = fMMSE(y, H, Sim_Param);
			sym_all = [sym_all s_est(Sim_Param.nonzero_indx)];
			
			% ----- Classic OMP Algorithm -----
			alg = alg + 1;
			LegendTxt{alg} = 'OMP';
			Alg_ParamOMP.K = K_est(1);
			%Alg_ParamOMP.K = K;
			[s_est] = fOMP(y, H, Sim_Param, Alg_ParamOMP);
			sym_all = [sym_all s_est(Sim_Param.nonzero_indx)];
			
			% ----- Classic OMP Algorithm -----
			alg = alg + 1;
			LegendTxt{alg} = 'OMP_{slice}';
			Alg_ParamOMP.K = K_est(2);
			%Alg_ParamOMP.K = K;
			s_est = fOMP_slice(y, H, Sim_Param, Alg_ParamOMP);
			sym_all = [sym_all s_est(Sim_Param.nonzero_indx)];
            

			% ----- Classic CoSaMP Algorithm -----
			alg = alg + 1;
			LegendTxt{alg} = 'CoSaMP_{slice}';
			Alg_ParamOMP.K = K;
			%Alg_ParamOMP.K = K;
			s_est = fCoSaMP_slice(y, H, Sim_Param, Alg_ParamOMP);
			sym_all = [sym_all s_est(Sim_Param.nonzero_indx)];
			
			
			% ----- MMP Algorithm -----
            L = 10;
			alg = alg + 1;
			LegendTxt{alg} = 'MMP';
			Alg_ParamMMP.MaxIter = K_est(3);
			Alg_ParamMMP.child_len = L;
			s_est = fMMP(y, H, Sim_Param, Alg_ParamMMP);
			sym_all = [sym_all s_est(Sim_Param.nonzero_indx)];
			
			
			% ----- MMP Algorithm -----
			alg = alg + 1;
			LegendTxt{alg} = 'sMMP';
			Alg_ParamMMP.MaxIter = K_est(4);
			Alg_ParamMMP.child_len = L;
			s_est = fMMP_slice(y, H, Sim_Param, Alg_ParamMMP);
			sym_all = [sym_all s_est(Sim_Param.nonzero_indx)];
			

			err_all = sym_all - repmat(s(nonzero_indx), 1, size(sym_all, 2));
			err = err + sum(err_all ~= 0);
			ncnt = ncnt + m;
		
		end
	end
	
	ser(:,tst) = err/ncnt
	fprintf('SNR = %d dB finished \n',snr_dB);

end
%%==========================================================================================


xTxt = sprintf('SNR (dB)');
yTxt = sprintf('SER');
smart_plot(TitleTxt, LegendTxt, xTxt, yTxt, snr_dB_vec, ser, alg);
