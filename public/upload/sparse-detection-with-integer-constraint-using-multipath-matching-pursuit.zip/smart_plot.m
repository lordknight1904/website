%
% plotERR
%
% Y_axis(:, algorithm)
function [] = smart_plot(TitleTxt, LegendTxt, xTxt, yTxt, X_axis, Y_axis, alg)

if length(X_axis) ==  size(Y_axis,1)
    % ok    
elseif length(X_axis) ==  size(Y_axis,2)
    Y_axis = Y_axis';
else
    fprintf('Something wrong in the smart_plot dimension -- check it out\n');
end
    
FigType = { '--','-v','-o','-d','-*','-s','-+','-x','-p','-<'};

LegendTxtAll = 'legend(';
for v = 1:length(LegendTxt)
    if v == length(LegendTxt)
        LegendTxtAll = sprintf('%s \''%s\'');',LegendTxtAll,LegendTxt{v});
    else
        LegendTxtAll = sprintf('%s \''%s\'',',LegendTxtAll,LegendTxt{v}); 
    end
end

%LegendTxtAll


SerTxt = 'figure;semilogy(';
for u = 1:alg
    if u == alg
        SerTxt = sprintf('%s X_axis,Y_axis(:,%d),\''%s\''', SerTxt,u,FigType{u});
    else
        SerTxt = sprintf('%s X_axis,Y_axis(:,%d),\''%s\'',', SerTxt,u,FigType{u});
    end
end
SerTxt = sprintf('%s);grid;',SerTxt);

title_txt = 'title(';
TitleTxtAll = sprintf('%s %s\'');',title_txt,TitleTxt);

eval(SerTxt);
eval(TitleTxtAll);
xlabel(xTxt);
ylabel(yTxt);
eval(LegendTxtAll);
