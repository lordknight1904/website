%
% fOracleMMSE
%
function x_est = fOracleMMSE(y,  H, Sim_Param)

  H2 = H(:, Sim_Param.nonzero_indx);
  x_mmse = inv(H2'*H2 + Sim_Param.npow*eye(size(H2,2)))*H2'*y;
  
  x_mmse = Sim_Param.sym_scale * x_mmse; % multiple sqrt(10) or sqrt(2)
  
  x_est	= zeros(Sim_Param.n, 1);
  
  x_est(Sim_Param.nonzero_indx)	= fslice(x_mmse, Sim_Param.sym_int); % integer slicing
  
  x_est = x_est/Sim_Param.sym_scale;

end