% ===========================================
%
%
%
% fMMP
%
%
% r: received vector
% H: channel matrix
% NoisePow: noise power
%
% Alg_Param:
% Alg_Param.MaxIter = 6; % number of iterations (heights of the tree)
% Alg_Param.child_len = 4; % number of children being searched(spanned) per each node
% Alg_Param.cand_len = 6; % total number of candidates per each layer
% ===========================================
function [x_est] = fMMP(y, H, Sim_Param, Alg_Param)


    [x_mmp x_supp indx_depth] = MMP_core(y, H, Sim_Param, Alg_Param);
    
%    test2 = x_supp
	x_est = randn(Sim_Param.n,1)+j*randn(Sim_Param.n,1);
    
    x_est(x_supp) = x_mmp(x_supp); % integer slicing
    
	x_est = Sim_Param.sym_scale * x_est; % multiple sqrt(10) or sqrt(2)
    x_est = fslice(x_est, Sim_Param.sym_int); % integer slicing
	x_est = x_est/Sim_Param.sym_scale;

end


%�¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�?��
% Estimate the sparse signal x using MMP
%
% y			: observation
% Phi		: Sensing matrix
% MaxIter	: Number of iterations (sparsity)
% child_len	: The size of expanding tree
% cand_len	: The pruning size of support sets
%
%	Output parameters
% x_est     : estimated signal
% x_supp	: selected support vector indice.
% indx_depth	: iteration count during estimating
%
% Written by Seokbeop Kwon
% Information System Lab., Korea Univ.
%�¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�?��
function [x_est x_supp indx_depth] = MMP_core(y, Phi,Sim_Param, Alg_Param) %MaxIter, child_len, cand_len)
	
    MaxIter = Alg_Param.MaxIter;
    child_len = Alg_Param.child_len;
    cand_len = Alg_Param.cand_len;
    reg_factor = Alg_Param.reg_factor;
    
	[nRows nCols]	= size(Phi);

	if nargin < 3
		disp('Parameters are not enough.');
	end

	indx_depth		= 0;

	% Define the hash function for performance issues.
	my_hash_f	= @sum;
	
	s_path_info				= struct(	'supps', zeros(MaxIter,1),...
										'residu', zeros(nRows, 1),...
										'eps', Inf,...
										'suppHash', int32(0));
	clear('best_path_par');
	
	best_path_par(child_len)	= s_path_info;
    
    
	% Initialize the best path.
	[supp_mag supp_indx]	= sort(abs(Phi'*y), 'descend');
	for indx=1:child_len
		supps	= supp_indx(indx);
        reg0 = 0.01;
		x_hat	= Est_LS(y, Phi(:,supps), reg0);
		residu	= y - Phi(:,supps)*x_hat;

		best_path_par(indx).supps	= supps;
		best_path_par(indx).residu	= residu;
		best_path_par(indx).eps		= norm(residu);
		best_path_par(indx).suppHash	= my_hash_f(supps);
	end

	% General iteration
	indx_add		= child_len;

	while (indx_depth < MaxIter-1)
        
		indx_depth	= indx_depth+1;
		
		if cand_len > 0
			search_len	= min(length(best_path_par), cand_len);
		else
			search_len	= length(best_path_par);
		end
		indx_add		= 0;
		clear('best_path_t');

		best_path_t_cell = cell(search_len, 1);
		for indx_best=1:search_len
		% for parallel running.
		%parfor indx_best=1:search_len

			[supp_mag supp_indx] = sort(abs(Phi'*best_path_par(indx_best).residu), 'descend');

			% Generate the child nodes
			for indx_child=1:child_len
				supps	= union(best_path_par(indx_best).supps, supp_indx(indx_child));
				x_hat	= Est_LS(y, Phi(:,supps), reg0);
				residu	= y - Phi(:,supps)*x_hat;

				best_path_t_cell{indx_best}{indx_child}			= s_path_info;
				best_path_t_cell{indx_best}{indx_child}.supps	= supps;
				best_path_t_cell{indx_best}{indx_child}.residu	= residu;
				best_path_t_cell{indx_best}{indx_child}.eps		= norm(residu);
				best_path_t_cell{indx_best}{indx_child}.suppHash = my_hash_f(supps);
			end
		end
		
		% Check the duplicated nodes
		best_path_par_t	= VerifyDuplication(best_path_t_cell, search_len, child_len);
		
		if cand_len > 0
			best_path_par	= iplsp_utilsCOMP_CV_Prunning(best_path_par_t, cand_len); % Prune the nodes
		else
			best_path_par	= best_path_par_t;
		end
		
	end
	
	[mag indx]		= sort([best_path_par(:).eps]);
	
	x_supp			= best_path_par(1).supps;
	x_est			= zeros(nCols, 1);
	x_est(x_supp)	= Est_LS(y, Phi(:,x_supp), reg_factor);

end

% �¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�?��
% Estimate the signal x using the regularized least squares
%
% y		: observation
% A	: Sensing matrix
% Written by Seokbeop Kwon
% Information System Lab., Korea Univ.
% �¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�?��
function [x_ls] = Est_LS(y, H, reg_factor)
	
    x_ls = (H'*H + reg_factor*eye(size(H,2)))\(H' * y);
        
end



%�¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�?��
% Estimate the sparse signal x using OMPM
%
% Written by Seokbeop Kwon
% Information System Lab., Korea Univ.
% �¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�?��
function [b_path] = VerifyDuplication(supp_sets, nRow, nCol)

	clear('b_path');
	
	for indx=1:nCol
		b_path(indx)	= supp_sets{1}{indx};
	end
	
	indx_added	= nCol;
	arr_hash = zeros(1, nCol);
	
	for indx=uint32(2:nRow)

% % performance solver 5
		for indx2=uint32(1:nCol)
			arr_hash(indx2)	= supp_sets{indx}{indx2}.suppHash;
		end
		
		bit_indx		= ismember([b_path(:).suppHash], arr_hash);
		
		for pos_indx = find(bit_indx)
			candi_indx	= find(arr_hash == b_path(pos_indx).suppHash);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%		Bug is fixed by sbkwon. 2012/08/31
%			if ~isempty(candi_indx)
%				tmp_supp	= union(b_path(pos_indx).supps, supp_sets{indx}{candi_indx}.supps);
%				if length(tmp_supp) == length(b_path(pos_indx).supps)
%					arr_hash(candi_indx)	 = 0;
%				end
%			end
			for c_indx = candi_indx
				tmp_supp	= union(b_path(pos_indx).supps, supp_sets{indx}{c_indx}.supps);

				if length(tmp_supp) == length(b_path(pos_indx).supps)
					arr_hash(c_indx)	 = 0;
				end
			end
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		end
		
		for pos_indx = find(arr_hash)
			indx_added			= indx_added+1;
			b_path(indx_added)	= supp_sets{indx}{pos_indx};
		end

end

end


function [result] = iplsp_utilsCOMP_CV_Prunning(sets, desired_len)

	[mag indx]	= sort([sets(:).eps]);
	
	result		= sets(indx(1:min(length(sets), desired_len)));
end
