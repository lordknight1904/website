%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  slice : slice the input
%
%  function: slice(xin, modmode) 
%  xin: input or input vector
%  modmode: constellation vector
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xout] = fslice(xin ,symvec)%, bsymvec)

%     for v = 1:length(xin)
%         xout(v) = near_point(xin(v), symvec);    
%     end
    
    for v = 1:size(xin,1)
        for w = 1:size(xin,2)
            %[xout(v,w) bout(v,:)] = near_point(xin(v,w), symvec)%, bsymvec);           
            xout(v,w) = near_point(xin(v,w), symvec);%, bsymvec);          
        end
    end
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xout bout] = near_point(xin, symvec)%, bsymvec)
[MinVal, MinIndx] = min(abs(symvec - xin));
xout = symvec(MinIndx);
%bout = bsymvec(MinIndx,:);
 
 