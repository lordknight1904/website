% ===========================================
%
% fOMP
%
% Originally by skwon 2010
% Modified by bshim 2013
%
%
% ------------------------------------------
% I/O parameters:
% ------------------------------------------
% y: received vector
% H: channel (sensing) matrix
% npow: noise power
% ===========================================
function [x_est] = fCoSaMP_slice(y, H, Sim_Param, Alg_Param)

	K = Alg_Param.K;
	max_itr		= 30;
	epsil		= 0.001;
	
	[x_est iter_count] = cosamp(H,y,K,epsil, max_itr);

	x_est = Sim_Param.sym_scale * x_est; % multiple sqrt(10) or sqrt(2)
	x_est = fslice(x_est, Sim_Param.sym_int); % integer slicing
	x_est = x_est/Sim_Param.sym_scale;
  
end


