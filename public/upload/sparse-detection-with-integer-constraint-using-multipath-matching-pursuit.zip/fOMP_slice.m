% ===========================================
%
% fOMP
%
% Originally by skwon 2010
% Modified by bshim 2013
%
%
% ------------------------------------------
% I/O parameters:
% ------------------------------------------
% y: received vector
% H: channel (sensing) matrix
% npow: noise power
% ===========================================
function [x_est] = fOMP_slice(y, H, Sim_Param, Alg_Param)

	K = Alg_Param.K;
	npow = Sim_Param.npow;
	[x_est support] = OMP_core(y, H, K, Sim_Param);

	x_est = Sim_Param.sym_scale * x_est; % multiple sqrt(10) or sqrt(2)
	x_est = fslice(x_est, Sim_Param.sym_int); % integer slicing
	x_est = x_est/Sim_Param.sym_scale;
  
end


function [x_omp support] = OMP_core(y, H, K, Sim_Param)

    rho = [0.1:0.1:1];
    rho = [rho ones(1,10)];
    %epsilon1 = Th;
    %epsilon2 = Th/8;
    n = size(H,2);
    max_k = K; %min(K, n)
    
    TotalSet = 1:n;
    
    support  = [];
    r = y;
    LeftSet  = TotalSet;
    
    
    k = 0;
    while (1) %norm(r) > epsilon1) % && (size(H(:,support),2) <= size(y))
        
        k = k + 1;
        
        % ================ stopping conditions ================
        if k > max_k
            break;
        end
%         if k > 2
%             if (norm(prev_r) - norm(r)) < epsilon2
%                 break;
%             end
%         end
        
        % ================ support update ================
        [val indx]  = max(abs(H(:,LeftSet)'*r));
        support   = [support LeftSet(indx)];
                
        HT = H(:,support);
        
        % ================ LS solution ================
        x_tmp = (HT'*HT + rho(k)*eye(k))\(HT'*y);
        
        x_tmp = Sim_Param.sym_scale * x_tmp; % multiple sqrt(10) or sqrt(2)
        x_tmp = fslice(x_tmp, Sim_Param.sym_int); % integer slicing
        x_tmp = x_tmp/Sim_Param.sym_scale;
  
        xomp = x_tmp;
        
        % ================ residual update ================
        prev_r  = r;
        r  = y - HT*xomp;
        LeftSet = setxor(TotalSet, support);
        
    end



% original code
%x_omp = zeros(n,1);
x_omp = randn(n,1)+j*randn(n,1);
x_omp(support) = xomp;

end
 
