% ===========================================
%
% fOMP
%
% Originally by skwon 2010
% Modified by bshim 2013
%
%
% ------------------------------------------
% I/O parameters:
% ------------------------------------------
% y: received vector
% H: channel (sensing) matrix
% npow: noise power
% ===========================================
function [x_est epsilon] = fOMP_CV_slice(y1, y2, H1, H2, Sim_Param, Alg_Param)

	K_max = Alg_Param.K_cv;
	%Th = sqrt(Sim_Param.npow*size(H,2));
	npow = Sim_Param.npow;
	[x_omp support epsilon] = OMP_CV_slice_core(y1, y2, H1, H2, K_max, Sim_Param);

	x_est	= x_omp;
%	x_omp = Sim_Param.sym_scale * x_omp; % multiple sqrt(10) or sqrt(2)
%	x_est = fslice(x_omp(support), Sim_Param.sym_int); % integer slicing
%	x_est = x_est/Sim_Param.sym_scale;
end


function [x_omp x_support epsilon] = OMP_CV_slice_core(y1, y2, H1, H2, K_max, Sim_Param)

    %epsilon1 = Th;
    %epsilon2 = Th/8;
    rho = [0.1:0.1:1];
    rho = [rho ones(1,10)];    
    n = size(H1,2);    
    
    TotalSet = 1:n;    
    
    support  = [];
    r = y1;
    LeftSet  = TotalSet;
    
    min_eps		= Inf;
	
    k = 0;
    while (1) %norm(r) > epsilon1) % && (size(H(:,support),2) <= size(y))
        
        k = k + 1;
        
        % ================ stopping conditions ================ 
        if k > K_max
            break;
        end
%         if k > 2            
%             if (norm(prev_r) - norm(r)) < epsilon2
%                 break;
%             end
%         end
        
        % ================ support update ================         
        [val indx]  = max(abs(H1(:,LeftSet)'*r));
        support   = [support LeftSet(indx)];
                
        HT = H1(:,support);
        
        % ================ LS solution ================            
        x_tmp = (HT'*HT + rho(k)*eye(k))\(HT'*y1);
        
        x_tmp = Sim_Param.sym_scale * x_tmp; % multiple sqrt(10) or sqrt(2)
        x_tmp = fslice(x_tmp, Sim_Param.sym_int); % integer slicing
        x_tmp = x_tmp/Sim_Param.sym_scale;
  
        xomp = x_tmp;
        
        % ================ residual update ================
        prev_r  = r;
        r  = y1 - HT*xomp;
        LeftSet = setxor(TotalSet, support);
        
        % ================ epsilon update ================      
%         epsilon(k)	= norm(y2 - H2(:,support)*xomp);
%         x_omps(k)	= xomp;
% 		x_support(k)= support;
		epsilon		= norm(y2 - H2(:,support)*xomp);
		if min_eps > epsilon
			x_omp			= zeros(n,1);
			x_omp(support)	= xomp;
			x_support		= support;
			min_eps			= epsilon;
		end
	end
% 
% 	if 0
% 		figure;plot(epsilon);grid on;
% 		pause;
% 	end
% 
% 	[min_val min_idx]	= min(epsilon);
% 	
% 	% original code
% 	x_omp = zeros(n,1);
% 	x_omp(support) = xomp;
% 
% 	support			= x_support(min_idx);
% 	x_omp(support)	= x_omps(min_idx);
end   
 
