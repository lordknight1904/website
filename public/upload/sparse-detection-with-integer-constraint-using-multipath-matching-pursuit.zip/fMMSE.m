%
% fMMSE
%
function x_est = fMMSE(y, H, Sim_Param)

if 0 ~= Sim_Param.npow 
	x_mmse = (H'*H + Sim_Param.npow*eye(size(H,2)))\(H'*y);
else
	x_mmse = H\y;
end
	[sig_mag sig_idx] = sort( abs(x_mmse),'descend');

	x_est	= zeros(Sim_Param.n, 1);

	x_mmse	= Sim_Param.sym_scale * x_mmse; % multiple sqrt(10) or sqrt(2)
	x_est	= fslice(x_mmse, Sim_Param.sym_int); % integer slicing
	x_est	= x_est/Sim_Param.sym_scale;
end
