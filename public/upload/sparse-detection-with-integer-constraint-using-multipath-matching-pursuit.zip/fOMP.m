% ===========================================
%
% fOMP
%
% Originally by skwon 2010
% Modified by bshim 2013
%
%
% ------------------------------------------
% I/O parameters:
% ------------------------------------------
% y: received vector
% H: channel (sensing) matrix
% npow: noise power
% ===========================================
function x_est = fOMP(y, H, Sim_Param, Alg_Param)

	K = Alg_Param.K;
	Th = sqrt(Sim_Param.npow*size(H,2));
	npow = Sim_Param.npow;
	[x_est support] = OMP_core(y, H, K, Th, Sim_Param);

	x_est = Sim_Param.sym_scale * x_est; % multiple sqrt(10) or sqrt(2)
	x_est = fslice(x_est, Sim_Param.sym_int); % integer slicing
	x_est = x_est/Sim_Param.sym_scale;
end



function [x_omp support] = OMP_core(y, H, K, Th, Sim_Param)

    rho = [0.1:0.1:1];
    rho = [rho ones(1,10)];
    epsilon1 = Th;
    epsilon2 = Th/8;
    n = size(H,2);
    max_k = K; %min(K, n)
    
    TotalSet = 1:n;
    
    support  = [];
    residual = y;
%     LeftSet  = TotalSet;
%
%     k = 0;
%     while (1) %norm(r) > epsilon1) % && (size(H(:,support),2) <= size(y))
%         
%         k = k + 1;
%         
%         % ================ stopping conditions ================
%         if k > max_k
%             break;
%         end
% %         if k > 2
% %             if (norm(prev_r) - norm(r)) < epsilon2
% %                 break;
% %             end
% %         end
%         
%         % ================ support update ================
%         [val indx]  = max(abs(H(:,LeftSet)'*r));
%         support   = [support LeftSet(indx)];
%                 
%         HT = H(:,support);
%         
%         % ================ LS solution ================
%         xomp = (HT'*HT + rho(k)*eye(k))\(HT'*y);
%   
%         % ================ residual update ================
%         prev_r  = r;
%         r  = y - HT*xomp;
%         LeftSet = setxor(TotalSet, support);
%         
% 	end

	iter_count		= 0;
	for vnum=1:max_k
		iter_count		= iter_count+1;
		[val idx]		= max(abs(H'*residual));
		
		u_supp			= union(support, idx);
		if length(support) ~= length(u_supp)
			support		= u_supp;
			%x_tmp		= iplsp_EstLS(y, H(:,support));
			HT		= H(:,support);
			x_tmp	= (HT'*HT + rho(iter_count)*eye(iter_count))\(HT'*y);

			residual	= y- H(:,support)*x_tmp;
		else
			disp('Selected the support which is selected on the previous iterations');
			break;
		end
	end

	if 0
		%xomp = (HT'*HT + npow*eye(size(HT,2)))\(HT'*y);
		%x_omp = (H'*H + npow*eye(size(H,2)))\(H'*y);

		org_indices = Sim_Param.nonzero_indx
		new_indices = support
		fprintf('=================\n\n');
	end

	% original code
	x_omp = zeros(n,1);
	%x_omp = randn(n,1)+j*randn(n,1);
	x_omp(support) = x_tmp;
end