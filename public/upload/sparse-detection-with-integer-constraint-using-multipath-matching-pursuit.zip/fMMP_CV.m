% ===========================================
%
% fOMP
%
% Originally by skwon 2010
% Modified by bshim 2013
%
%
% ------------------------------------------
% I/O parameters:
% ------------------------------------------
% y: received vector
% H: channel (sensing) matrix
% npow: noise power
% ===========================================
function [x_est epsilon] = fMMP_CV(y1, y2, H1, H2, Sim_Param, Alg_ParamMMP)

	K_max = Alg_ParamMMP.K_cv;
	%Th = sqrt(Sim_Param.npow*size(H1,2));
	npow = Sim_Param.npow;
	[x_mmp support epsilon] = MMP_CL_core(y1, y2, H1, H2, K_max, Sim_Param, Alg_ParamMMP);

	x_est	= x_mmp;
%	x_mmp = Sim_Param.sym_scale * x_mmp; % multiple sqrt(10) or sqrt(2)
%	x_est = fslice(x_mmp(support), Sim_Param.sym_int); % integer slicing
%	x_est = x_est/Sim_Param.sym_scale;
end

%%
function [x_mcmp support epsilon] = MMP_CL_core(y1, y2, Phi1, Phi2, K_max, Sim_Param, Alg_ParamMMP)


	[nRows nCols]	= size(Phi1);

    child_len = Alg_ParamMMP.child_len;
    cand_len = Alg_ParamMMP.cand_len;
	idx_depth		= 0;
    stop = K_max;

	%% Define the hash function for performance issues.
	my_hash_f	= @sum;

	s_path_info				= struct(	'supps', zeros(stop,1),...
										'residu', zeros(nRows, 1),...
										'x_hat', zeros(nCols, 1),...
										'prev_inv', zeros(1, 1),...
										'eps', Inf,...
										'suppHash', int32(0));
	clear('best_path_par');

	best_path_par(child_len)	= s_path_info;
	%% Initialize the best path.
	[supp_mag supp_idx]	= sort(abs(Phi1'*y1), 'descend');
	for idx=1:child_len
		supps	= supp_idx(idx);
		x_hat	= y1\ Phi1(:,supps);
		residu	= y1 - Phi1(:,supps)*x_hat;

		best_path_par(idx).supps	= supps;
		best_path_par(idx).residu	= residu;
		best_path_par(idx).x_hat	= x_hat;
		best_path_par(idx).prev_inv	= 1/(norm(Phi1(:,supps))^2);
		best_path_par(idx).eps		= norm(residu);
		best_path_par(idx).suppHash	= my_hash_f(supps);
	end

	%% General iteration
	idx_add		= child_len;

	while (idx_depth < stop-1)
%		t1 = tic;
		idx_depth	= idx_depth+1;

		search_len	= min(length(best_path_par), cand_len);
		idx_add		= 0;
		clear('best_path_t');

		best_path_t_cell	= cell(search_len, 1);
		for idx_best = 1 : search_len

			[supp_mag supp_idx]	= sort(abs(Phi1'*best_path_par(idx_best).residu), 'descend');

			% Generate the child nodes
			for idx_child = 1 : child_len

                supps	= [best_path_par(idx_best).supps supp_idx(idx_child)];
				reuse_Minv	= best_path_par(idx_best).prev_inv;
				reuse_b		= Phi1(:,best_path_par(idx_best).supps)'*Phi1(:,supp_idx(idx_child));

				xi			= reuse_b'*reuse_Minv;

				reuse_p		= 1/(norm(Phi1(:,supp_idx(idx_child)))^2 - reuse_b'*reuse_Minv*reuse_b);
				%reuse_inv	= [(reuse_Minv+reuse_p*reuse_Minv*reuse_b*reuse_b'*reuse_Minv) (-reuse_p*reuse_Minv*reuse_b);(-reuse_p*reuse_b'*reuse_Minv) reuse_p];
				reuse_inv	= [(reuse_Minv+reuse_p*xi'*xi) (-reuse_p*xi');(-reuse_p*xi) reuse_p];
				x_hat		= reuse_inv*[(Phi1(:,best_path_par(idx_best).supps)'*y1) ; (Phi1(:,supp_idx(idx_child))'*y1)];
				residu	= y1 - Phi1(:,supps)*x_hat;

				best_path_t_cell{idx_best}{idx_child}			= s_path_info;
				best_path_t_cell{idx_best}{idx_child}.supps		= supps;
				best_path_t_cell{idx_best}{idx_child}.residu	= residu;
				best_path_t_cell{idx_best}{idx_child}.x_hat		= x_hat;
				best_path_t_cell{idx_best}{idx_child}.prev_inv	= reuse_inv;
				best_path_t_cell{idx_best}{idx_child}.eps		= norm(residu);
				best_path_t_cell{idx_best}{idx_child}.suppHash	= my_hash_f(supps);

            end
        end

		% Check the duplicated nodes
		best_path_par_t	= islsp_VerifyDuplication(best_path_t_cell, search_len, child_len);

		% Prune the nodes
		best_path_par	= iplsp_utilsCOMP_CV_Prunning(best_path_par_t, cand_len);

    end

    % Examine the residual of each path
    for q = 1 : search_len

        supp_cand = best_path_par(q).supps;
        for t = 1 : stop
            residu2(t) = norm(y2 - Phi2(:, supp_cand(1:t))*(Phi2(:, supp_cand(1:t))\y2))^2;
        end

        [minval cut_idx] = min(residu2);
        x_supp{q} = best_path_par(q).supps(1:cut_idx);
        r_pwr(q) = residu2(cut_idx);

    end

    % Select the path with minimum residual magnitude
    [minval minidx] = min(r_pwr);
    x_supp_fin = x_supp{minidx};
    epsilon = 0;

    Phi = [ Phi1 ; Phi2 ];
    y = [ y1 ; y2 ];
    support = sort(x_supp_fin);
    x_mcmp = zeros(size(Phi,2),1);
    x_mcmp(x_supp_fin) = pinv(Phi(:,x_supp_fin))*y;


end

function [b_path] = islsp_VerifyDuplication(supp_sets, nRow, nCol)

	clear('b_path');
	
	for idx=1:nCol
		b_path(idx)	= supp_sets{1}{idx};
	end
	
	idx_added	= nCol;
	arr_hash = zeros(1, nCol);
	
	for idx=uint32(2:nRow)

% % performance solver 5
		for idx2=uint32(1:nCol)
			arr_hash(idx2)	= supp_sets{idx}{idx2}.suppHash;
		end
		
		bit_idx		= ismember([b_path(:).suppHash], arr_hash);
		
		for pos_idx = find(bit_idx)
			candi_idx	= find(arr_hash == b_path(pos_idx).suppHash);
%			if ~isempty(candi_idx)
			for c_idx = candi_idx
				tmp_supp	= union(b_path(pos_idx).supps, supp_sets{idx}{c_idx}.supps);

				if length(tmp_supp) == length(b_path(pos_idx).supps)
					arr_hash(c_idx)	 = 0;
				end
			end
%			end
		end
		
		for pos_idx = find(arr_hash)
			idx_added			= idx_added+1;
			b_path(idx_added)	= supp_sets{idx}{pos_idx};
		end

	end
	
%	b_path(idx_added+1:end) = [];
end

function [result] = iplsp_utilsCOMP_CV_Prunning(sets, desired_len)

	[mag idx]	= sort([sets(:).eps]);
	
	result		= sets(idx(1:min(length(sets), desired_len)));
end