%%%%%%%%%%%%%%%---------------------------------------
%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%    
%%%%%%%%%%%%%%%     SD_PTP
%%%%%%%%%%%%%%%     perform "Schnorr-Euchner ordering" based sphere decoding
%%%%%%%%%%%%%%%     perform complex numbered system as it is
%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%     solve s_est = arg min_{s} || rcv - Hs ||^2
%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%     input:
%%%%%%%%%%%%%%%         y : received vector (real-valued only)
%%%%%%%%%%%%%%%         R : QR-decomposed upper triangular matrix (square-matrix only)
%%%%%%%%%%%%%%%         radius_in : externally set radius
%%%%%%%%%%%%%%%         s_set : finite set of real number
%%%%%%%%%%%%%%%     output:
%%%%%%%%%%%%%%%         s_out : sphere decoded output
%%%%%%%%%%%%%%%         radius_out : path metric of s_out, 
%%%%%%%%%%%%%%%                     i.e., || rcv - H s_out ||^2       
%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%     Oct. 2006
%%%%%%%%%%%%%%%     All rights reserved
%%%%%%%%%%%%%%%     bshim
%%%%%%%%%%%%%%%---------------------------------------
function [s_out, radius_out, n_nodes] = SD_PTP(y, R, radius_in, s_set, beta)

              
%%%%%%%%%%%%%%%----------------------------------------------
%%%%%%%%%%%%%%% Preparation
%%%%%%%%%%%%%%%----------------------------------------------
max_layer = size(R, 2);
max_dist = radius_in;

%%%%%%%%%%%%%%%----------------------------------------------
%%%%%%%%%%%%%%% Initialization
%%%%%%%%%%%%%%%----------------------------------------------
Ns = length(s_set);
dist = zeros(1, max_layer+1);
b = zeros(1, max_layer);
a = zeros(1, max_layer);
s = zeros(1, max_layer);
s_index = zeros(1, max_layer);
order_flag = zeros(1, max_layer);
ordered_s_set = zeros(max_layer, Ns);
terminate = 0;
s_min_index = ones(1, max_layer);


%%%%%%%%%%%%%%%----------------------------------------------
%%%%%%%%%%%%%%% Initialization for PTP-SD algorithm
%%%%%%%%%%%%%%%----------------------------------------------
%beta = [0 chi2inv(prune_prob, 1:max_layer-1)];


% starting parameter (start from the bottom layer)
ii = max_layer;
dist(ii+1) = max_dist;
constraint = max_dist;
b(ii) = y(ii);
a(ii) = R(ii,ii);
n_nodes = 0;
while(~terminate)
      
    if ~order_flag(ii)
        threshold = 0;
        [ordered_s_set(ii,:), s_max_index(ii)] = s_ordering_schnorr_euchner2(a(ii), b(ii), constraint-beta(ii), s_set);        
        order_flag(ii) = 1;
    end
        
    [found_s, s(ii), s_index(ii), branch_dist] = find_s (a(ii), b(ii), constraint-beta(ii), s_max_index(ii), s_min_index(ii), ordered_s_set(ii,:), Ns);
       
    n_nodes = n_nodes + 1;
    
    %%%%%%%%%%%%%%%------------------------------------------- 
    %%%%%%%%%%%%%%% if not found (s_k is not existing)
    %%%%%%%%%%%%%%% then go back to the down-layer (re-search)
    %%%%%%%%%%%%%%%      if fail to find it, set error-flag and terminate
    %%%%%%%%%%%%%%%-------------------------------------------
    if ~found_s
        if ii == max_layer % fail to find any candidate        
            radius_out = radius_in;
            terminate = 1;          
        else
            % since branch is out-of-the-candidate
            % we need to re-do ordering, also set s_min(ii) = 1
            s_min_index(ii) = 1;
            order_flag(ii) = 0; % do we need to do this? --> yes
            constraint = dist(ii+2);
            
            ii = ii+1; % go back to previous-layer    
            % dist(ii), a(ii), b(ii) should be same as before                      
            s_min_index(ii) = s_index(ii)+1; % previous s(k) should be removed from candidate            
           
        end              
    %%%%%%%%%%%%%%%---------------------------------------------
    %%%%%%%%%%%%%%% if found (s_ii is existing)
    %%%%%%%%%%%%%%% then go forward 
    %%%%%%%%%%%%%%%      if we finished top-layer, then terminate   
    %%%%%%%%%%%%%%%---------------------------------------------    
    else
        if ii == 1 % finished top(final)-layer                 
            
            dist(ii) = dist(ii+1) - branch_dist;            
            s_out = s;
            radius_out = max_dist - dist(ii);
                        
            dist = dist - (radius_in - radius_out); % dist update
            constraint = dist(ii+2);
            order_flag(ii) = 0; % do we need to do this? --> yes
            
            ii = ii + 1;
            s_min_index(ii) = s_index(ii)+1; % previous s(ii) should be removed from candidate (refer @1)   
             
        else
            dist(ii) = dist(ii+1) - branch_dist;
            constraint = dist(ii);
            
            ii = ii-1; % go forward to upper-layer
            b(ii) = y(ii) - R(ii,ii+1:end) * s(ii+1:end).';
            a(ii) = R(ii,ii);            
        end                
    end % if ~found_s
    
end % (~terminate)



%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%% find_s
%%%%%%%%%%%%%%% find s s.t dist >= | b - a s |^2   
%%%%%%%%%%%%%%%                                  
function [found_s, s, s_index, branch_dist] = find_s (a, b, dist, s_max_index, s_min_index, ordered_s_set, Ns)
        
found_s = 0;        
branch_dist = 0;   % meaningless 
s = 1;             % meaningless
s_index = 1;       % meaningless
 
if (s_min_index <= s_max_index)           
	for v = s_min_index:s_max_index     
        radius_s = (abs( b - a*ordered_s_set(v) ))^2;
              
		if dist >= radius_s
			s = ordered_s_set(v);
            s_index = v;                     
            branch_dist = radius_s;
			found_s = 1;
			break;
        end
	end	    
% else
%  found_s = 0;
%  branch_dist = 0;   % meaningless 
%  s = 1;             % meaningless
%  s_index = 1;       % meaningless
end
     

% %%%%%%%%%%%%%%% 
% %%%%%%%%%%%%%%% s_ordering
% %%%%%%%%%%%%%%%   
% function [ordered_s_out] = s_ordering_schnorr_euchner(a, b, s_set)
% 
%     %%%%%%%%%%%% sort s based on metric given by | b - a s |^2         
%     metric = abs(b - a * s_set);
%     sorted = sortrows([metric ; s_set].');
%     ordered_s_out  = sorted(:,2).';
    
%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%% s_ordering + max_index
%%%%%%%%%%%%%%%   
function [ordered_s_out, s_max_index] = s_ordering_schnorr_euchner2(a, b, dist, s_set)

    %%%%%%%%%%%% sort s based on metric given by | b - a s |^2         
    metric = abs(b - a * s_set).^2 ;    
    sorted = sortrows([metric ; s_set].');
    ordered_s_out  = sorted(:,2).';
    ordered_metric = sorted(:,1).';
    
    statistic = dist - ordered_metric;
    
    index = 1:length(s_set);
    index(statistic < 0) = 0;
    s_max_index = max(find(index ~= 0));
    
    if (s_max_index)
       % do nothing 
    else
        s_max_index = 0;
    end       
    