% =========================================================================
%
%
% sd_sim_main
%
%
% =========================================================================
function [xsnr, ser, avg_n_nodes] = sd_test_main(size_matrix, mod_mode, MAX_SNR, start_SNR, Basic_Unit)

start_clk = clock;


if mod_mode == 1    
Mod = [1+j 1-j -1+j -1-j]/sqrt(2);
Mod = Mod';

realMod = [-1 1]/sqrt(2);

intMod = [1+j 1-j -1+j -1-j]';
intMod2 = [-1 1];
denom = sqrt(2);

elseif mod_mode == 2
Mod = [1+j 1-j -1+j -1-j 1+3j 1-3j -1+3j -1-3j 3+j 3-j -3+j -3-j 3+3j 3-3j -3+3j -3-3j]/sqrt(10);
Mod = Mod';

realMod = [-3 -1 1 3]/sqrt(10);

intMod = [1+j 1-j -1+j -1-j 1+3j 1-3j -1+3j -1-3j 3+j 3-j -3+j -3-j 3+3j 3-3j -3+3j -3-3j]';
intMod2  = [-3 -1 1 3];
denom = sqrt(10);    

elseif mod_mode == 3
Mod = [1+j  1+3j  1+5j 1+7j 3+j  3+3j  3+5j 3+7j 5+j  5+3j  5+5j 5+7j 7+j  7+3j  7+5j 7+7j ...
    -1+j  -1+3j  -1+5j -1+7j -3+j  -3+3j  -3+5j -3+7j -5+j  -5+3j  -5+5j -5+7j -7+j  -7+3j  -7+5j -7+7j ...
    1-j  1-3j  1-5j 1-7j 3-j  3-3j  3-5j 3-7j 5-j  5-3j  5-5j 5-7j 7-j  7-3j  7-5j 7-7j ...
    -1-j  -1-3j  -1-5j -1-7j -3-j  -3-3j  -3-5j -3-7j -5-j  -5-3j  -5-5j -5-7j -7-j  -7-3j  -7-5j -7-7j ]/sqrt(42);
Mod = Mod';

realMod = [-7 -5 -3 -1 1 3 5 7]/sqrt(42);

intMod = [1+j  1+3j  1+5j 1+7j 3+j  3+3j  3+5j 3+7j 5+j  5+3j  5+5j 5+7j 7+j  7+3j  7+5j 7+7j ...
    -1+j  -1+3j  -1+5j -1+7j -3+j  -3+3j  -3+5j -3+7j -5+j  -5+3j  -5+5j -5+7j -7+j  -7+3j  -7+5j -7+7j ...
    1-j  1-3j  1-5j 1-7j 3-j  3-3j  3-5j 3-7j 5-j  5-3j  5-5j 5-7j 7-j  7-3j  7-5j 7-7j ...
    -1-j  -1-3j  -1-5j -1-7j -3-j  -3-3j  -3-5j -3-7j -5-j  -5-3j  -5-5j -5-7j -7-j  -7-3j  -7-5j -7-7j ]';
intMod2 = [-7 -5 -3 -1 1 3 5 7];
denom = sqrt(42);

end
length_Mod = length(Mod);

%-------- Matrix size setup
m = size_matrix;

n_alg = 7; % max number of algorithm
ner = zeros(MAX_SNR, n_alg);

step_SNR = 2;




for SNR_loop = 1:MAX_SNR
    
    NUMSIM = SNR_loop * Basic_Unit;
    SNR_dB = start_SNR + (SNR_loop - 1)*step_SNR        
    SNR = sqrt((1/m) * 10.^(SNR_dB/10));  

ncnt = 0;
err = zeros(1,n_alg); 
max_nodes = zeros(1, n_alg);
num_nodes = zeros(1, n_alg);
for n = 1:NUMSIM
   
    %----------------------------
    % 1) Symbol & Channel Generation
    %----------------------------
    indx = ceil(rand(m,1) * length_Mod);
    s_org = Mod(indx);
    int_s_org = intMod(indx);

    H = (randn(m,m) + j*randn(m,m))/sqrt(2);    
    B = SNR * H ;
    noise = (randn(m,1)+j*randn(m,1))/sqrt(2);
      
    y = B * s_org + noise;
    
    
    alg = 1;
    %----------------------------
    % 2.1) joint LMMSE
    %----------------------------
    Ryy = B * B' + eye(m);
    Rsy = B';
    W = Rsy * inv(Ryy);
    s = W * y;

    %--------------------------
    % 2.2) SER measure
    %--------------------------
    for v = 1:m
        I_s_slice = int_slice(s(v),mod_mode);
        if (I_s_slice ~= int_s_org(v))
            err(alg) = err(alg) + 1;        
        end 
    end      
    
    
    %----------------------------
    % 3.1) SD (prune_prob = 0 <-- Original SD)
    %----------------------------  
    alg = alg + 1;
    Bi = real(B);
    Bq = imag(B);
    [Qmat Rmat] = qr([Bi -Bq ; Bq Bi]);
    max_layer = size(Rmat,2);    

    y2 = [real(y) ; imag(y)];
    rcv = Qmat' * y2;
        
    if n == 1
        prune_prob = 0.0;
        beta0 = [0 chi2inv(prune_prob, 1:max_layer-1)];
    end
    radius_in = 10000;
    [s_final, radius_out, n_nodes] = SD_PTP(rcv, Rmat, radius_in, realMod, beta0);
    s = s_final(1 : end/2) + sqrt(-1)*s_final(end/2 + 1 : end);
    s = s.'; 

    %--------------------------
    % 3.2) SER measure
    %--------------------------
    num_nodes(alg) = num_nodes(alg) + n_nodes;
    max_nodes(alg) = max(max_nodes(alg), n_nodes);
    for v = 1:m
        I_s_slice = int_slice(s(v),mod_mode);
        if (I_s_slice ~= int_s_org(v))
            err(alg) = err(alg) + 1;        
        end 
    end     
    
    
    %----------------------------
    % 4.1) PTP-SD
    %----------------------------  
    alg = alg + 1;
    Bi = real(B);
    Bq = imag(B);
    [Qmat Rmat] = qr([Bi -Bq ; Bq Bi]);
    y2 = [real(y) ; imag(y)];
    rcv = Qmat' * y2;
    
        
    radius_in = 10000;
    if n == 1
        prune_prob = 0.05;
        beta005 = [0 chi2inv(prune_prob, 1:max_layer-1)];
    end
    [s_final, radius_out, n_nodes] = SD_PTP(rcv, Rmat, radius_in, realMod, beta005);
    s = s_final(1 : end/2) + sqrt(-1)*s_final(end/2 + 1 : end);
    s = s.'; 

    %--------------------------
    % 4.2) Complexity & SER measure
    %--------------------------
    num_nodes(alg) = num_nodes(alg) + n_nodes;
    max_nodes(alg) = max(max_nodes(alg), n_nodes);
    for v = 1:m
        I_s_slice = int_slice(s(v),mod_mode);
        if (I_s_slice ~= int_s_org(v))
            err(alg) = err(alg) + 1;        
        end 
    end     
    
      
    %----------------------------
    % 5.1) PTP-SD
    %----------------------------  
    alg = alg + 1;
    Bi = real(B);
    Bq = imag(B);
    [Qmat Rmat] = qr([Bi -Bq ; Bq Bi]);
    y2 = [real(y) ; imag(y)];
    rcv = Qmat' * y2;
        
    radius_in = 10000;   
    if n == 1
        prune_prob = 0.10;
        beta010 = [0 chi2inv(prune_prob, 1:max_layer-1)];
    end
    [s_final, radius_out, n_nodes] = SD_PTP(rcv, Rmat, radius_in, realMod, beta010);
    s = s_final(1 : end/2) + sqrt(-1)*s_final(end/2 + 1 : end);
    s = s.'; 

    %--------------------------
    % 5.2) Complexity & SER measure
    %--------------------------
    num_nodes(alg) = num_nodes(alg) + n_nodes;
    max_nodes(alg) = max(max_nodes(alg), n_nodes);
    for v = 1:m
        I_s_slice = int_slice(s(v),mod_mode);
        if (I_s_slice ~= int_s_org(v))
            err(alg) = err(alg) + 1;        
        end 
    end     
    
    
    %----------------------------
    % 6.1)  PTP-SD
    %----------------------------  
    alg = alg + 1;
    Bi = real(B);
    Bq = imag(B);
    [Qmat Rmat] = qr([Bi -Bq ; Bq Bi]);
    y2 = [real(y) ; imag(y)];
    rcv = Qmat' * y2;
        
    radius_in = 10000;    
    if n == 1
        prune_prob = 0.20;
        beta020 = [0 chi2inv(prune_prob, 1:max_layer-1)];
    end
    [s_final, radius_out, n_nodes] = SD_PTP(rcv, Rmat, radius_in, realMod, beta020);
    s = s_final(1 : end/2) + sqrt(-1)*s_final(end/2 + 1 : end);
    s = s.'; 

    %--------------------------
    % 6.2) Complexity & SER measure
    %--------------------------
    num_nodes(alg) = num_nodes(alg) + n_nodes;
    max_nodes(alg) = max(max_nodes(alg), n_nodes);
    for v = 1:m
        I_s_slice = int_slice(s(v),mod_mode);
        if (I_s_slice ~= int_s_org(v))
            err(alg) = err(alg) + 1;        
        end 
    end
    
    %----------------------------
    % 7.1)  PTP-SD
    %----------------------------  
    alg = alg + 1;
    Bi = real(B);
    Bq = imag(B);
    [Qmat Rmat] = qr([Bi -Bq ; Bq Bi]);   
    y2 = [real(y) ; imag(y)];
    rcv = Qmat' * y2;
        
    radius_in = 10000;    
    if n == 1
        prune_prob = 0.4;
        beta040 = [0 chi2inv(prune_prob, 1:max_layer-1)];
    end
    [s_final, radius_out, n_nodes] = SD_PTP(rcv, Rmat, radius_in, realMod, beta040);
    s = s_final(1 : end/2) + sqrt(-1)*s_final(end/2 + 1 : end);
    s = s.'; 

    %--------------------------
    % 7.2) Complexity & SER measure
    %--------------------------
    num_nodes(alg) = num_nodes(alg) + n_nodes;
    max_nodes(alg) = max(max_nodes(alg), n_nodes);
    for v = 1:m
        I_s_slice = int_slice(s(v),mod_mode);
        if (I_s_slice ~= int_s_org(v))
            err(alg) = err(alg) + 1;        
        end 
    end     
    
    ncnt = ncnt + m;

end        


xsnr(SNR_loop) = SNR_dB;
ner(SNR_loop,:) = err;
ser(SNR_loop,:) = ner(SNR_loop,:)/ncnt;
avg_n_nodes(SNR_loop,:) = num_nodes/ncnt;
max_node(SNR_loop,:) = max_nodes;
end 

xsnr
ner
ser
avg_n_nodes = avg_n_nodes*m % ncnt is added by m
max_node



    
figure;plot(xsnr,avg_n_nodes(:,2),'-v', ...
    xsnr,avg_n_nodes(:,3),'-o', ...  
    xsnr,avg_n_nodes(:,4),'-d', ...
    xsnr,avg_n_nodes(:,5),'-*', ...
    xsnr,avg_n_nodes(:,6),'-<');grid;
xlabel('SNR (dB)');
ylabel('Average number of nodes visited');
legend('SD','PTP-SD (0.05)','PTP-SD (0.1)','PTP-SD (0.2)','PTP-SD (0.4)');

figure;semilogy(xsnr,ser(:,1),'--', ...
    xsnr,ser(:,2),'-v', ...
    xsnr,ser(:,3),'-o', ... 
    xsnr,ser(:,4),'-d', ...
    xsnr,ser(:,5),'-*', ...
    xsnr,ser(:,6),'-<');grid;
xlabel('SNR (dB)');
ylabel('SER');
legend('MMSE','SD','PTP-SD (0.05)','PTP-SD (0.1)','PTP-SD (0.2)','PTP-SD (0.4)');




fprintf('size_matrix: complex wise %d, real wise %d\n\n',m,2*m);



