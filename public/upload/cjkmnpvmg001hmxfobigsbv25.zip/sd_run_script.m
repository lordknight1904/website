%
%
% sd_run_script
%
%
function [done] = sd_run_script()


DimMat = 2;            % Dimension of channel matrix (Nt = Nr)
MOD_mod = 3;           % 1: QPSK, 2: 16-QAM, 3: 64-QAM
SNR_start = 12;        % Starting SNR
NumSNR = 8;            % Number of SNR points
Nsim = 400;           % Number of simulation runs
sd_test_main(DimMat, MOD_mod, NumSNR, SNR_start, Nsim); % m_complex = 1,16-QAM
