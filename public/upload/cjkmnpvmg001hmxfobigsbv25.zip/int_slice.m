%
% int_slice
%
function [s_out] = int_slice(rcv,mode)

if mode == 3 % 64-QAM
    
    rcv = sqrt(42)*rcv;
    s_out_re = slice(real(rcv));
    s_out_im = slice(imag(rcv));
    s_out = s_out_re + j*s_out_im;

elseif mode == 2 % 16-qam
    
    rcv = sqrt(10)*rcv;     

    s_out_re = 2*(real(rcv)>2) + (real(rcv)>0) - (real(rcv)<=0) - 2*(real(rcv)<=-2);
    s_out_im = 2*(imag(rcv)>2) + (imag(rcv)>0) - (imag(rcv)<=0) - 2*(imag(rcv)<=-2);
    s_out = s_out_re + j*s_out_im;

elseif mode == 1 % qpsk
    
    s_out_re = 2*(real(rcv)>0) - 1;
    s_out_im = 2*(imag(rcv)>0) - 1;
    s_out = s_out_re + j*s_out_im;
    
    
    %pause;
end

function [s_out] = slice(rcv)

if rcv > 0
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if rcv > 4
        if rcv > 6
            s_out = 7;
        else
            s_out = 5;
        end
    else
        if rcv > 2
            s_out = 3;
        else
            s_out = 1;
        end            
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
else
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if rcv > -4
        if rcv > -2
            s_out = -1;
        else
            s_out = -3;
        end
    else
        if rcv > -6
            s_out = -5;
        else
            s_out = -7;
        end            
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
end
    



