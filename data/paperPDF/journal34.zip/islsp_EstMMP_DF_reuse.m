%�¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�
% Estimate the sparse signal x using MMP-DF
%
% y				: observation
% Phi			: Sensing matrix
% K				: Sparsity
% L				: Selection length
% stop_threshold: Selection length
% max_itr		: Selection length
%
%	Output parameters
% x_mmp_est		: estimated signal
% x_supp		: selected support vector indice.
% candiate_idx	: iteration count during estimating
%
% Written by Suhyuk (Seokbeop) Kwon
% Information System Lab., Korea Univ.
%�¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�


function [x_mmp_est x_supp candiate_idx] = islsp_EstMMP_BF_reuse(y, Phi, K, L, stop_threshold, max_itr)
	

	[nRows nCols]	= size(Phi);
	
	x_mmp_est		= zeros(nCols, 1);
	
	node_header				={	'supps',...
								'x_h',...
								'residu',...
								'prev_inv',...
								'suppHash',...
								'idx_stored_children'};

	n_ideal_candidate_len	= 0;
	n_searched_cand_n		= 0;
	
	residu_min				= Inf;
	
	clear('store_nodes');
	
	store_nodes				= cell(K, 1);
	
	my_hash_f				= @sum;
	
	[supp_mag supp_idx]	= sort(abs(Phi'*y), 'descend');
	for idx=1:L
		supps	= supp_idx(idx);
		x_hat	= Phi(:,supps) \ y;
		residu	= y - Phi(:,supps)*x_hat;
		store_nodes{1}(idx) = cell2struct({supps, x_hat, residu, 1/(norm(Phi(:,supps))^2), my_hash_f(supps), zeros(L, 1)}', node_header, 1);
	end
	
	%%
	pre_cal_cand		= [];
	idx_pre_cal_cand	= 0;
	
	while( stop_threshold < residu_min && max_itr > n_searched_cand_n && L^K > n_ideal_candidate_len )
		
		n_ideal_candidate_len	= n_ideal_candidate_len + 1;
		n_searched_cand_n		= n_searched_cand_n + 1;
		
		% Check the pre-checked path
		if 0 ~= ismember(n_ideal_candidate_len, pre_cal_cand)
			n_searched_cand_n	= n_searched_cand_n - 1;
			continue;
		end

		%% Generate the path
		search_order	= islsp_GenSearchOrder(n_ideal_candidate_len, K, L);

		idx_parent		= search_order(1);
		cell_node_p		= store_nodes{1}(idx_parent);
		
		%% Find the path
		depth_idx	= 2;
		while ( depth_idx < K+1)
			idx_curr	= search_order(depth_idx);
			
			% Check the child existence.
			if 0 == cell_node_p.idx_stored_children(idx_curr)
				% Generate and save the child idx
				[supp_mag supp_idx]	= sort(abs(Phi'*cell_node_p.residu), 'descend');
				child_supps	= [cell_node_p.supps supp_idx(idx_curr)];
				% Check the stored node

				idx_stored = islsp_CheckDupliecated(	...
								store_nodes{depth_idx},...
								child_supps,...
								my_hash_f(child_supps));
							
				% If the stored node is not exist, then save the new child node.
				if 0 == idx_stored
					idx_stored	= size(store_nodes{depth_idx}, 2)+1;
					store_nodes{depth_idx}(idx_stored)		= ...
							cell2struct(islsp_GenChildNodeReUse(cell_node_p,...
																supp_idx(idx_curr),...
																y,...
																Phi,...
																L,...
																my_hash_f),...
										node_header, 1);
				end
% 				toc
				% Save the child node information on parent node.
				store_nodes{depth_idx-1}(idx_parent).idx_stored_children(idx_curr)	= idx_stored;
			else
				% Search the alternative next path since the child exists.
				% Get alternative next path
				[search_order idx_changed]	= GetAltNextPath(search_order, depth_idx, K, L);
				if 0 > idx_changed
					% Should move to the next path
					cell_node_p		=...
						store_nodes{K}(cell_node_p.idx_stored_children(idx_curr));
					break;
				end
				idx_next_cand	= islsp_GenerateCandOrd( search_order, L );

				idx_pre_cal_cand	= idx_pre_cal_cand+1;
				pre_cal_cand(idx_pre_cal_cand)		= idx_next_cand;

				if idx_changed ~= depth_idx
					depth_idx		= idx_changed;
					tmp_idx_node	= 2;
					idx_parent		= search_order(1);

					% Parent node information update
					while( tmp_idx_node < idx_changed)
						idx_parent	= ...
							store_nodes{tmp_idx_node-1}(idx_parent).idx_stored_children(search_order(tmp_idx_node));
						
						tmp_idx_node = tmp_idx_node+1;
					end

					cell_node_p		= store_nodes{depth_idx-1}(idx_parent);
				end
				
				continue;
			end

			idx_parent		= idx_stored;
			cell_node_p		= store_nodes{depth_idx}(idx_stored);
			
			depth_idx		= depth_idx+1;
		end
		
		residue_tmp	= norm(cell_node_p.residu);

		
		if residu_min > residue_tmp
			residu_min						= residue_tmp;

			x_mmp_est						= zeros(nCols, 1);
			x_mmp_est(cell_node_p.supps)	= cell_node_p.x_h;
			x_supp							= sort(cell_node_p.supps);

			candiate_idx					= n_searched_cand_n;
		end
	end

end

%%
function [child_nodes] = islsp_GenChildNode(cell_node_p, supp_new, y, Phi, L, my_hash_f)

	supps		= [cell_node_p.supps supp_new];

	x_hat		= Phi(:,supps) \ y;
	residu		= y - Phi(:,supps)*x_hat;

	child_nodes = {supps, x_hat, residu, 1, my_hash_f(supps), zeros(L, 1)}';
end


%%
function [child_nodes] = islsp_GenChildNodeReUse(cell_node_p, supp_new, y, Phi, L, my_hash_f)

	reuse_Minv	= cell_node_p.prev_inv;
	reuse_b		= Phi(:,supp_new)'*Phi(:,cell_node_p.supps);

	xi			= reuse_b*reuse_Minv;

	reuse_p		= 1/(norm(Phi(:,supp_new))^2 - reuse_b*xi');
	reuse_inv	= [(reuse_Minv+reuse_p*xi'*xi) (-reuse_p*xi');(-reuse_p*xi) reuse_p];

	x_hat		= reuse_inv*[(Phi(:,cell_node_p.supps)'*y) ; (Phi(:,supp_new)'*y)];

	supps		= [cell_node_p.supps supp_new];

	residu		= y - Phi(:,supps)*x_hat;

	child_nodes = {supps, x_hat, residu, reuse_inv, my_hash_f(supps), zeros(L, 1)}';
end

%%
function [search_order] = islsp_GenSearchOrder(idx_candidate, K, L)
	search_order	= zeros(1, K);
	TmpIdx	= idx_candidate-1;
	for pos=1:K
		search_order(pos)	= mod(TmpIdx, L)+1;
		TmpIdx	= floor(TmpIdx/L);
	end
end

%%
function [search_order idx_changed_pos] = GetAltNextPath(search_order, depth_idx, K, L)
	tmp_depth	= depth_idx;
	
	while (L == search_order(tmp_depth) && tmp_depth < K+1)
		if tmp_depth+1 > K
			break;
		end
		
		search_order(tmp_depth) = 1;
		tmp_depth	= tmp_depth+1;
	end
	
	% No more next path
	if L == search_order(tmp_depth)
		idx_changed_pos = -1;
		return ;
	end
	
	search_order(tmp_depth)	= search_order(tmp_depth)+1;
	idx_changed_pos		= tmp_depth;
end

%%
function [exist_idx] = islsp_CheckDupliecated(stored_nodes, new_supps, suppHash)
	exist_idx	= 0;
	
	if length(stored_nodes) < 1
		return	;
	end

	hash_idx	= ismember([stored_nodes.suppHash], suppHash);
	
	for pos_idx = find(hash_idx)
		supp1	= sort(stored_nodes(pos_idx).supps);
		supp2	= sort(new_supps);
		
		if isequal(supp1, supp2)
			exist_idx	= pos_idx;
			return	;
		end
	end
end

%%
function cand_order_num = islsp_GenerateCandOrd(search_order, L)
	len		= length(search_order);
	cand_order_num	= search_order(1);
	for idx=2:len
		cand_order_num = cand_order_num + (search_order(idx)-1)*L^(idx-1); 
	end
end
