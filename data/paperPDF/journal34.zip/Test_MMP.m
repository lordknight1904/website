%�¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�
% Test MMP algorithm
%
% Written by Suhyuk (Seokbeop) Kwon
% Information System Lab., Korea Univ.
% http://isl.korea.ac.kr
%�¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢¢�


% Measurements size
m		= 50;
% Signal size
N		= 100;
% Sparsity level
K		= 20;


% Generate sensing matrix
Phi = randn(m,N)/sqrt(m);

% Generate sparse vector
[x x_pos]	= islsp_GenSparseVec(N, K);

y	= Phi*x;

% Child length
L = 4;

% Find the sparse vector via MMP-BF
[x1	x1_supps itr1]	= islsp_EstMMP_BF_reuse(y, Phi, K, L, 10);

N_MAX = 50;
% Find the sparse vector via MMP-DF
[x2	x2_supps itr2]	= islsp_EstMMP_DF_reuse(y, Phi, K, L, 1e-6, N_MAX);


disp('Mean square error');
[mse(x-x1) mse(x-x2)]

